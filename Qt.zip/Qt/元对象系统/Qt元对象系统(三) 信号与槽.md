---
title: Qt元对象系统(三) 信号与槽
categories:
  - Qt
abbrlink: 9bd610a7
date: 2018-05-10 20:35:07
---

## 引述

我们从普通的点击按钮过程来看一下信号与槽的运行机制。先运行一个普通的QWidget程序，添加一个按钮，定义一个槽函数`test`，函数体里做个断点，调试运行，可以看到从回调函数qt_internal_proc开始，一直到槽函数。元对象系统的调用层次如下
![](https://c1.staticflickr.com/1/832/27145612477_11c7542db2_z.jpg)
`QAbstractButtonPrivate::click`和`QAbstractButtonPrivate::emitClicked`属于源码部分，而且代码比较简单，直接看信号`QAbstractButton::clicked`

## 信号函数

前面提到我们声明的信号是由moc工具在moc_.cpp中实现的，例如：
```
// 有参数的信号
void Widget::valueChanged(double _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
```
首先是指针数组 _a 的定义，它是用于传递从信号到槽函数的参数的，_a 里面第一个指针是Q_NULLPTR(就是NULL)，这个指针是预留给 元对系统内部注册元方法参数类型时使用; 第二个指针是参数_t1的指针；如果有更多的参数，那么会继续将指针填充到_a里面。

## activate函数

`QMetaObject::activate`函数是负责联络接收方槽函数的，它根据源头对象指针 this、源头的元对象指针 &staticMetaObject、信号序号 2、信号参数数组_a 去找寻需要激活的槽函数，最终会调用每个关联到该信号的槽函数。

遍历所有receiver并触发它们的slots。针对不同的连接类型，这里的派发逻辑会有不同。看源码:
```cpp
void QMetaObject::activate(QObject *sender, int signalOffset ......)
{
	. . . . . .
	//发送方和接收方是否在同一个线程中
  const bool receiverInSameThread =  currentThreadId == receiver->d_func()->threadData->threadId;
  //决定连接立刻发送还是加入事件队列
  if ((c->connectionType == Qt::AutoConnection && !receiverInSameThread)
      || (c->connectionType == Qt::QueuedConnection))
      {
      queued_activate(sender, signal_index, c, argv ? argv : empty_argv, locker);
      continue;
  }
  else if (c->connectionType == Qt::BlockingQueuedConnection)
  {
      if (receiverInSameThread) {	// 如果是BlockingQueued类型且同一线程，报死锁
          qWarning("Qt: Dead lock detected while activating a BlockingQueuedConnection: "
          "Sender is %s(%p), receiver is %s(%p)",  省略);
      }
      QSemaphore semaphore;
      QMetaCallEvent *ev = c->isSlotObject    ?
          new QMetaCallEvent(c->slotObj, sender, signal_index, 0, 0, argv ? argv : empty_argv, &semaphore)    :
          new QMetaCallEvent(c->method_offset, c->method_relative, c->callFunction, sender, signal_index, 0, 0, argv ? argv : empty_argv, &semaphore);
      QCoreApplication::postEvent(receiver, ev);
}
	//不是以上情况，则直接调用关联的槽
	. . . . . . 
```

再看`queued_activate`:
```cpp
static void queued_activate(QObject *sender, int signal, QObjectPrivate::Connection *c, void **argv,  QMutexLocker &locker)
{
  ...
     QMetaCallEvent *ev = c->isSlotObject ?
     new QMetaCallEvent(c->slotObj, sender, signal, nargs, types, args) :
     new QMetaCallEvent(c->method_offset, c->method_relative, c->callFunction, 
                        sender, signal, nargs, types, args);

    //post事件到接收者所属线程的QThreadData::postEventList队列中
     QCoreApplication::postEvent(c->receiver, ev);
  ...
}
```
 postEvent第二个参数是QMetaCallEvent，这个signal-slot的connection就发送到receiver的消息队列中，这是线程安全的，通过这种方法Qt实现了跨线程的signal-slot传递。除了信号触发线程与接收者线程相同的情况能直接调用到slot，其它情况都依赖事件机制，也就是说receiver线程必须要有eventloop，否则slot函数是没有机会触发的。

##  qt_static_metacall()

这个函数是私有静态函数，用于处理当前类的元方法调用以及信号函数相对序号查询，qt_metacall() 会调用这个私有静态函数。

## 自动关联函数

对于在ui模式中添加的信号，在moc_.cpp中看不到，但是打开ui_.h可以看到一个函数:`QMetaObject::connectSlotsByName(MainWindow);`，它被称为自动关联函数。自动关联的过程就是根据字符串匹配查找发送源头、信号，然后关联到 object 对象自己的槽函数。发送源头通常是 object 对象自己的内部成员，比如大窗口里面的一堆子控件，子控件的信号关联到大窗口自己的槽函数。

它是一个静态函数，源码在qobject.cpp:
```cpp
// internal slot-name based connect
static void connectSlotsByName(QObject *o);	// o可以是MainWindow
```
代码太复杂，大致过程是：
1. 将QObject对象的children和自身加入对象列表。
2. 获取元对象mo和包含的所有元方法，检查其名称是不是以`on_`开头，如果不是则跳过，如果是则进入内层循环。
3. 对对象列表中的名称和slot里的signal name对比，如果匹配则查找发送端信号的绝对序号sigIndex，找到后调用`QMetaObjectPrivate::connect`实现关联，跳出循环。

四种连接类型：

- QueuedConnection：sender和receiver不在同一线程，sender向receiver所在线程的消息循环发送事件，此事件得到处理时会调用slot，像Win32的::PostMessage。

- BlockingQueuedConnection：处理方式和QueuedConnection相同，但发送信号的线程会等待信号处理结束再继续，像Win32的::SendMessage。

- DirectConnection：在当前线程直接调用receiver的slot，这种类型无法支持跨线程的通信。

- AutoConnection：信号发射时的当前线程和槽函数关联的线程不一致时，用QueuedConnection方式，否则用DirectConnection


`sender`函数在slot函数中调用可以获取发送该signal的对象，但仅用于同一线程的`Qt::DirectConnection`连接的 signal。由于这种做法破坏了面向对象的原则，慎用！

## 其他

Qt4中的信号与槽匹配是在运行时检查的，Qt5引入了函数指针关联语法，这样可以在编译期间检查。

 QObject::deletelater() 。从源码可以看出，这个调用也只是发送了一个事件，等对象所属线程的消息循环获取控制权来处理这个事件时做真正的delete操作。
所以调用这个方法要谨慎，确保对象所属线程具有激活的eventloop，不然这个对象就被泄露了

Qt5中，信号槽是有返回值的。只是Qt的一个信号可以连接多个槽，还有同步调用和异步调用的问题，没发支持的很好，所以，返回值虽有，但只是鸡肋。