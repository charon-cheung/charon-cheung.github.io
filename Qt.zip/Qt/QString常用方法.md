---
title: QString常用方法
date: 2018-11-28 21:51:00
categories:
- Qt
---


### 处理单引号情况

```
QString cmd = QString(" see this: '%1' ").arg(" I am single quote ");
```
结果cmd是` "see this: 'I am single quote" '

