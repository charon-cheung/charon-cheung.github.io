---
title: Qt常用命令和pro参数
date: 2018-07-25 11:57:08
categories:
- Qt
tags:
- 命令行
---

#### <center>Qt常用工具（命令行指令）</center>

位于<font color= orange> C:\Qt5.7.1\5.7\msvc2015_64\bin</font>

| 命令 |  功能 |
|:-:|:-:|
|assistant| 帮助文档|
|designer|设计器|
|linguist| 翻译工具 |
|lupdate|提取翻译字符串和生成ts文件|
|lrelease|从ts文件生成qm文件|
|moc |Qt Meta Object Compiler|
|qmake| 生成3个Makefile|
|mingw32-make| 生成build,release文件夹|
|rcc|资源文件编译器|
|uic|界面编译器，从ui文件生成代码|
|lconvert|转换ts文件为po文件等类型|

*******
## 以下为pro文件常用参数的使用
******
|DEFINES的宏|功能|
|:-:|:-:|
|QT_DEPRECATED_WARNINGS|编译器对deprecated API报警|
|QT_NO_DEBUG_OUTPUT|不输出打印信息 |

******
CONFIG配置工程和编译器的设置，以下取值定义了所要连编的库/应用程序的类型：

|CONFIG的宏|功能|
|:-:|:-:|
|console|只用于app,cmd窗口输出信息|
| windows|只用于app,说明是windows程序|
| thread| 多线程的程序|
| qt| Qt应用程序|
| dll| 只用于lib,库是共享库|
|staticlib| 只用于lib,库是静态库|
|plugin|只用于lib,库是插件|
|debug_and_release_target|默认编译配置|
| debug(release)|只用debug(release)，忽略编译器模式|
|orderd|subdirs类型时按目录顺序编译|
|warn_on|启用编译告警|
|warn_off|关闭编译告警|
|c++11|编译支持c++11|

*****
模板变量**TEMPLATE**规定qmake为应用程序生成哪种makefile。下面是可供使用的选择：

|TEMPLATE的宏|功能|
|:-:|:-:|
|app|应用程序|
|lib| 库dll|
|subdirs| 子项目|
|vcapp|应用的visual studio项目|
|vclib|库的visual studio项目|

******
#### <center> 其他常用qmake变量 </center>
|变量名|功能|
|:-:|:-:|
|RC_ICONS|程序的图标|
|DESTDIR|exe的路径，在build目录的子目录|
|RC_FILE|指定资源文件(Windows)|
|RES_FILE|需连接的资源文件(Windows)|
|RESOURCES|指定qrc文件|
|UI_DIR|ui*.h的路径|
|MOC_DIR|moc*.h和moc*.cpp的路径|
|OBJECTS_DIR|*.o的路径|
|RCC_DIR|qrc*.cpp的路径|
|INCLUDEPATH|编译时要搜索的include目录|
|INSTALLS|  |
|DEPENDPATH|应用所依赖的搜索路径|
|CODECFORSRC|编码方式,例如(GBK)|
|TRANSLATIONS|包含用户界面翻译的ts文件|
|QT_VERSION|Qt完整版本,如5.9.2|
|QT_MAJOR_VERSION|Qt主版本|
|QT_MINOR_VERSION|Qt次版本|
|QT_PATCH_VERSION|Qt补充版本|
|PWD|pro文件路径|
|OUT_PWD|build文件夹|
|QMAKESPEC|编译器的路径|

HEADERS 中的文件是否需要 moc 进行预处理，qmake 运行时会根据其是否含有Q_OBJECT自动判断。这也是添加**Q_OBJECT**宏后不重新运行qmake会出错误的原因。
<br>
******
#### <center> 常用qmake函数 </center>
|函数|功能|
|:-:|:-:|
|message|在General Messages输出|
|message($$(PATH))|输出环境变量|
|log|输出信息(不换行)|
|include|一般用于包含pri文件|
|greaterThan|常用于判断Qt版本|
|error|报警信息|

******
pro文件常用代码:
```
RC_ICONS = ruler.ico
DESTDIR = bin

UI_DIR = $$compiled/ui	# 存放ui_mainwindow.h之类文件
MOC_DIR = $$compiled/moc   # 存放moc文件
OBJECTS_DIR = $$compiled/obj	# 存放.o文件
RCC_DIR = $$compiled/res	# 存放资源文件

LIBS += -L folderPath  //引入的lib文件的路径  -L：引入路径
Release:LIBS += -L folderPath // release 版引入的lib文件路径
Debug:LIBS += -L folderPath // Debug 版引入的lib 文件路径
#引入的lib文件,用于引入动态链接库
LIBS += qaxcontainer.lib
#工程中包含的资源文件
RESOURCES   = Scintilla.qrc
BINLIB = ../../bin ../../xercesc/lib
QMAKE_LIBDIR = $${BINLIB}
```