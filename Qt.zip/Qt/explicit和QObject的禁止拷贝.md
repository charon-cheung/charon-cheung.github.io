---
title: explicit关键字和QObject的禁止拷贝
date: 2018-04-28 18:02:53
categories:
- Qt
---

常用的mainwindow.h中对构造函数是这样声明的:`explicit MainWindow(QWidget *parent = 0);`，为什么有个explicit？其实是为了禁止构造函数的隐式转换。

构造函数如果只有一个参数，那么存在一个隐式转换，将参数的数据转换为该类的对象，比如String类：
```
class String
{
	public:
	String(const char* p);
	String ( int n );
	......
}
```
我们常常这样使用：`String s = "abcd";`，这其实就是隐式转换。比较正规的写法应该是`String s("abcd");`
再看这个类：
```
class MyClass {
public:
     MyClass(int num);
};
```
`MyClass my = 10;`可以编译通过，这显然不是我们所希望的。所以在构造函数之前加`explicit`关键字，让构造函数只能用显示转换，之后上面的赋值语句就会报错`error: conversion from 'int' to non-scalar type 'MyClass' requested`。
对于拥有两个及以上的形参的构造函数，没有隐式转换，也就没必要加`explicit`了，

好了，明白了explicit的作用，我们来试试在MainWindow中去掉explicit，然后然后进行隐式转换会怎么样：
```
MainWindow m;
m = nullptr;
```
结果还是报错：
```
error: 'QMainWindow& QMainWindow::operator=(const QMainWindow&)' is private  Q_DISABLE_COPY(QMainWindow)`
error: use of deleted function 'MainWindow::MainWindow(const MainWindow&)'
```
这是怎么回事？`Q_DISABLE_COPY`又是谁？我们按报错打开Qt源码：
```
private:
	Q_DISABLE_COPY(QMainWindow)

#define Q_DISABLE_COPY(Class) \
    Class(const Class &) Q_DECL_EQ_DELETE;\
    Class &operator=(const Class &) Q_DECL_EQ_DELETE;

# define Q_DECL_EQ_DELETE = delete
```
原来它是QObject私有的一个宏，定义在qtglobal.h，代表了拷贝构造函数和赋值操作符，为什么都声明为private呢？

根据Effective C++ 05条款，创建C++类后，编译时会自动生成default构造函数、copy构造函数、赋值操作符、析构函数。06条款又规定，如果不想用编译器自动生成的函数，就应该明确拒绝。

编译器生成的几个函数全是public的，当然是在我们没有自己定义情况下才会生成，那么如果我们自己给出了private的函数，编译器就不能处理了，这样在其他地方就不能调用这些函数了。06条款给出了更好的处理方法，就是创建一个基类，包括了这两个private函数，我们使用的类都继承自这个基类。在Qt中，QObject就是这个基类，**凡是继承QObject的类都不能使用拷贝构造函数和赋值操作符。**

宏`Q_DECL_EQ_DELETE`代表`=delete`，这是C++11的语法，显式指示编译器不生成函数的默认版本。无论调用层级，只要构造函数末尾加`=delete;`，编译器就不会生成它,所以会报错`error: use of deleted function 'MainWindow::MainWindow(const MainWindow&)'`，因为调用了没生成的拷贝构造函数。

那Qt为什么要这样做？
我们都知道Qt对标准C++增加了一些功能：signals, slots, object properties, events, event filters等等。这些功能就要求我们把每一个QObject的对象看做是唯一的，就是不能通过拷贝或者赋值操作制作出一个一模一样的复制体。比如QPushButton对象btn，如果我们可以复制出一个和btn完全一样的button对象，那么新的button对象的名字(objectName)应该是什么？如果也叫btn，当我们给其中的btn接收事件或发出信号时，系统如何区分把事件由哪个button对象接收，或者哪个对象发送了信号？

另外，各种容器中能以value方式存放的类型，必须有默认的构造函数，拷贝构造函数和赋值操作。因为容器进行元素的安插时，实际进行的是拷贝操作，存放的是元素的副本，所以对象需要具备拷贝构造函数。但是QObject及所有子类都没有提供拷贝构造和赋值操作，当我们使用QList<QObject>时，编译器就会报错。这就是为什么我们的代码都是使用它们的指针,即`QList<QObject*> objs;`

参考：[explicit 抑制构造函数隐式转换](https://blog.csdn.net/KjfureOne/article/details/72830001)