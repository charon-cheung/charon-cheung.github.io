---
title: 深入解析QSettings
date: 2018-12-05 21:32:37
categories:
- Qt
---

对于QSettings使用相对路径时，如果当前程序最终是exe，那么相对路径是生成可执行文件的，不是当前cpp的相对路径。如果程序最终编译为静态库，那么相对路径是基于调用这个库的可执行文件的。

常用函数:
```
contains() 判断一个指定的键是否存在
remove() 删除相关键
allkeys() 获取所有键
clear() 删除所有键
childGroups() 返回顶级组列表
childKeys() 返回顶级组列表所有子键
setvalue() 设置参数
value() 获取键值
```
构造函数的Format 默认为QSettings::NativeFormat, window 平台从注册表读取


ROS中使用QSettings时，给文件路径传空时，通过`QSettings::fileName()`显示ini文件路径是`/home/name/ROS/workspace`，如果要加载该目录下的`/config/setting.ini`，参数传入`./config/setting.ini`。
