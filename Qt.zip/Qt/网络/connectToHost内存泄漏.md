---
title: QTcpSocket::connectToHost内存泄漏的问题
date: 2018-05-23 11:06:50
categories:
- Qt
tags:
- 网络
---

使用QTcpSocket上网看博客时，发现有篇[抄来抄去的博客](https://blog.csdn.net/u011125673/article/details/50474491)提到QTcpSocket类的方法connectToHost会泄露内存，即使把调用这个方法的QTcpSocket实例delete掉，内存也不会释放。反复connectToHost会导致进程内存增长，必须控制connectToHost的使用次数！

于是我来亲自验证一下，仍然拿[之前写的Socket_Test](https://github.com/rjosodtssp/Socket_Test)进行测试。增加一个按钮，槽函数代码如下：
```
    QTimer *timer = new QTimer(this);
    timer->start(50);
    connect(timer,SIGNAL(timeout()),this,SLOT(Test()) );
```
槽函数Test的代码：
```
    tcpSocket->abort();
    tcpSocket->connectToHost(QHostAddress("192.168.0.100"),13000);
    connect(tcpSocket,SIGNAL(connected()),this,SLOT(OnServer()) );
```
也就是client高频率地与server进行开关连接。

启动server和一个client之后，点击按钮，到任务管理器看两个进程的内存情况，过一段时间后发现客户端的CPU和内存占用已经比较大了：
![](https://c1.staticflickr.com/1/975/40485559680_1e1eb0e29e_z.jpg)

由此看来真是有内存泄漏问题，`connectToHost`函数不能使用太多。查了很长时间找不到完美的解决方法，但是连接接近1000时才会有明显的影响。
