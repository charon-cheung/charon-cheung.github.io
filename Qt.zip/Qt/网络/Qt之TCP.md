---
title: Qt TCP & UDP 使用总结
date: 2018-05-22 20:03:08
categories:
- Qt
tags:
- 网络
---

使用Qt Network模块开发了一个UDP和TCP测试工具，client和server都写在一起，运行时先选择模式，其中TCP部分主要使用QTcpServer和QTcpSocket两个类，采用异步方式。开始是参考霍亚飞的《Qt Creator快速入门》，后来自己做了不少修改，现在对发现的问题做一下总结和思考。
代码地址：[Github上的代码](https://github.com/rjosodtssp/Socket_Test)

## Server部分
1. 霍亚飞的书上的listen函数是`tcpServer->listen(QHostAddress::LocalHost,6666)`，但我用了之后报错： <font color = red size =3> socket error 0 connection refused </font>，stackoverflow上说原始是win10的防火墙导致，IP还是要用本机的地址，修改之后正常了。

2. 霍亚飞的将tcpServer的`newConnection`信号与发送消息的槽相连。这个发送消息的功能，我试了试发现不能连续发送，里面用到了函数`nextPendingConnection`，返回的是下一个连接，这种时候就该上Qt源码：
```
    Q_D(QTcpServer);
    if (d->pendingConnections.isEmpty())	// 没有pending连接，返回
        return 0;
    if (!d->socketEngine) {
        qWarning("QTcpServer::nextPendingConnection() called while not listening");
    } else if (!d->socketEngine->isReadNotificationEnabled()) {
        d->socketEngine->setReadNotificationEnabled(true);
    }
    // 返回的是QList<QTcpSocket *> pendingConnections;的第一个元素
    return  d->pendingConnections.takeFirst();
```
来看看Qt官方的解释：用已连接的QTcpSocket对象返回下一个pending的连接。这个socket作为server的child，当QTcpServer对象销毁时也跟着销毁(Qt半自动内存回收机制)。使用完成时显式地销毁可避免浪费内存。（这句很关键）返回的QTcpSocket对象不能再另一个线程中使用，如果想在另一个线程使用一个incoming连接，就需要override 函数`incomingConnection()`

既然是取链表pendingConnections的第一个元素，那么它在哪添加元素的？很容易发现正是函数`incomingConnection()`：
```
void QTcpServer::addPendingConnection(QTcpSocket* socket)
{
	d_func()->pendingConnections.append(socket);
}

void QTcpServer::incomingConnection(qintptr socketDescriptor)
{
	QTcpSocket *socket = new QTcpSocket(this);
	socket->setSocketDescriptor(socketDescriptor);
	addPendingConnection(socket);
}
```
Qt官方对`incomingConnection`函数的解释：每当有新连接可用时，QTcpServer就会调用这个虚函数。参数socketDescriptor是连接的native socket descriptor. 。重写这个函数以改变新连接可用时的server行为，但不要忘了**手动添加**`addPendingConnection`函数。

如果想在另一个线程处理一个incoming connection，必须将socketDescriptor传到另一个线程，并在新线程创建QTcpSocket对象和使用`setSocketDescriptor()`方法。

3. 我开始在霍亚飞的程序基础上加了一个`hasPendingConnections`判断，结果发现首次是true，第二次发送消息就变成了false。此时如果再连接一个client，那么又是true，也就是对连接的判断是连续找下一个，无法再使用已经用过的连接发送消息。

我把tcpServer的`newConnection`信号与函数`OnNewClient`相连，每当有新的client连接至server，就把QTcpSoket指针对象添加到一个新的链表`QList<QTcpSocket*> sockets;`，当这个client解除连接，则把它删掉。实际思想跟源码是一样的。注意这个QList回收时要用`qDeleteAll`和`clear`。

在发送消息的函数中，遍历sockets进行发送：
```
    foreach (QTcpSocket* socket, sockets) {
        qDebug()<<socket->peerPort();	// 每个client的端口
        if(socket->write(ba)==-1)
            qDebug()<<socket->errorString();
    }
```
这样实现了连续发送消息。

4. 另外霍亚飞的程序中，tcpServer在触发`disconnected`信号后，调用了槽`deleteLater()`，最好还是不要这样做，有的操作在断开连接后可能还需要tcpServer，内存回收还是用半自动机制或手动回收。

## client部分

1. 霍亚飞的程序提到要在client连接之前，先关闭已有的连接，用的是`abort()`函数，但是还有一个`close`函数，这二者有什么不同？看源码：
```

void QAbstractSocket::close()
{
    Q_D(QAbstractSocket);
    QIODevice::close();
    if (d->state != UnconnectedState)
        disconnectFromHost();
}
```
关闭socket的I/O设备，关闭socket的连接。`disconnectFromHost`的源码的源码太长，只看官方解释：试图关闭socket，如果还有Pending数据等待写入，那么连接进入`ClosingState`并一直等待所有数据写入。最终进入`UnconnectedState`并发射`disconnected`信号。

`abort()`的源码如下:
```
void QAbstractSocket::abort()
{
    Q_D(QAbstractSocket);
    d->setWriteChannelCount(0);
    if (d->state == UnconnectedState)
        return;
#ifndef QT_NO_SSL
    if (QSslSocket *socket = qobject_cast<QSslSocket *>(this)) {
        socket->abort();
        return;
    }
#endif
    d->abortCalled = true;
    close();
}
```
官方解释：放弃当前连接，重置socket，与`disconnectFromHost()`不同，此函数立刻关闭socket，丢弃任何写入缓存里的pending数据，然后调用`close`。

显然我们不需要之前的缓存数据，所以调用的是`abort`。

2. 与霍亚飞的程序相比，我增加了`connected`和`disconnected`两个信号，用于管理客户端连接和断开的状态，在一个listWidget上显示出来。

3.  在翻墙状态下的连接问题，详见下一篇博文。

4. `connectToHost`的内存泄漏问题，详见另一篇博文