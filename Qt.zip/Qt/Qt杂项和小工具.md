---
title: Qt杂项和小工具
date: 2018-05-14 19:03:23
categories:
- Qt
---

1. qVersion：获取当前正在运行的Qt的版本号
```
qDebug()<<qVersion();	//5.10.1
```

2. qRound/qRound64：对浮点数取整，四舍五入
```
qDebug()<<qRound(5.345);	// 5
```

3. Q_GADGET：不需要从QObject继承就可以使用Qt的Meta Object功能

某些类，其父类不是 QObject 时，可以使用 Q_GADGET 代替 Q_OBJECT 宏，来实现枚举，属性和方法的脚本化，序列化，但是不支持信号与槽。
```
class Actor
{
    Q_GADGET
    Q_PROPERTY(QString name READ name WRITE setName)
public:
    QString name() const { return m_name; }
    void setName(const QString &name) { m_name = name; }
private:
 QString m_name;
}

 Q_DECLARE_METATYPE(Actor)
```
声明完，别忘记使用 Q_DECLARE_METATYPE 注册一下。



qCompress/qUncompress：基于zlib的算法对字节缓存区进行压缩/解压，可以自定义压缩比
qFuzzyCompare：线程安全的浮点数模糊比较，处理了浮点精度误差的问题
Q_ENUMS：对枚举对象进行反射（reflection）