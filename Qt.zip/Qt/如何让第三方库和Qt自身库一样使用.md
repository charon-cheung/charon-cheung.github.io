---
title: 如何让第三方库和Qt自身库一样使用
date: 2020-03-21 21:01:55
categories:
- Qt
---

Qt中添加模块都是编辑pro文件，比如`QT += network`，显然跟某些文件是对应的，加入我们自己编译了一个第三方库，怎么才能这样使用？

我们一般编译会生成`include/LibName`, `lib`(存放库文件), `mkspecs`几个文件夹。做如下操作即可：

- 库文件都放入`5.14.1\mingw73_64\bin`，就像Qt5Network.dll一样

- 头文件放入`5.14.1\mingw73_64\include`，就像QtWebSockets一样

- `mkspecs\modules`中的pri文件放入`5.14.1\mingw73_64\mkspecs\modules`中，就像qt_lib_sql.pri, qt_lib_svg.pri

现在可以优雅使用第三方库了，名称和pri文件的最后部分一样