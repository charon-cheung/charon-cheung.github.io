---
title: Qt Widget模块的常用方法
date: 2018-05-14 19:08:36
categories:
- Qt
tags:
---

### QWidget

某按钮的名称为MyBtn
```
btn->isWidgetType()   //bool值

QWidget *parent = btn->parentWidget();

QWidget::isWindow()  //是否为Window

QObject::inherits   //是否继承或为某个类

QObject::children()  //所有的children

QWidget::setDefault(true)    //将启动后的焦点放在某控件上，不是SetFocus()

QWidget::focusWidget()  //当前焦点所在的控件

QObject::setParent()  //确定parent

QWidget::setWindowIcon	// 窗口的图标，不是程序图标
```

几乎所有的QWidget的派生类都会重新实现paintEvent

### QComboBox

QComboBox默认无法编辑，如果需要手动输入，用`setEditable`

### QLineEdit

在QLineEdit里输入密码时需要开启密码模式:`ui->lineEdit->setEchoMode(QLineEdit::Password);`

限定QLineEdit最多输入字符的个数：`ui->lineEdit->setMaxLength(8);`

### QTabWidget

隐藏tabWidget某个tab：`removeTab`

QApplication::setStyle("Fusion")	// 改变界面风格为Fusion