---
title: Qt 父子对象管理
date: 2018-06-27 13:44:07
categories:
- Qt
---

## 几个常用的函数

从[半自动内存管理]一文可知Qt采用了树形的父子对象管理，所有对象都分配在heap上，Qt提供了几个函数管理这个对象树。
看代码:
```
QObject* pA1 = new QObject( Q_NULLPTR );
pA1->setObjectName( "A1" );
QObject* pB1 = new QObject( pA1 );
pB1->setObjectName( "B1" );
QObject* pB2 = new QObject( pA1 );
pB2->setObjectName( "B2" );
QObject* pC1 = new QObject( pB2 );
pC1->setObjectName( "C1" );
QObject* pC2 = new QObject( pB2 );
pC2->setObjectName( "C2" );
QObject* pC3 = new QObject( pB2 );
pC3->setObjectName( "C3" );
QObject* pD1 = new QObject( pC2 );
pD1->setObjectName( "D1" );
```

代码里建立了一个对象树，如果要获知某对象的直系子对象，用`children()`函数:
```
// d指针直接获得公有变量children
inline const QObjectList &children() const { return d_ptr->children; }

foreach(QObject* obj, pA1->children() )
   qDebug()<<obj->objectName();		// 输出B1, B2
```
要获得所有子对象就得用`findChildren()`，这个用的很多了:
```
// 不列出原型，仍是个内联函数
foreach(QObject* obj, pA1->findChildren<QObject*>(QString()) )
   qDebug()<<obj->objectName();
```
还有`qFindChild`和`qFindChildren`这两个函数，但用的不多，而且功能与`findChildren`相同，就不介绍了。

要获得父对象则很简单，直接用`parent()`函数:
```
//d指针直接获得公有变量
inline QObject *parent() const { return d_ptr->parent; }

qDebug()<<pD1->parent()->objectName();
```

Qt还提供了`dumpObjectTree`以输出对象树的整个情况，自Qt 5.9起，这个函数成为`const`，实际调用的是`dumpRecursive(0, this);`，这个函数不详细分析了，实际是根据对象树的层次数，递归地输出类名和对象名。

```
pA1->dumpObjectTree();
```
运行结果为:
```
QObject::A1 
    QObject::B1 
    QObject::B2 
        QObject::C1 
        QObject::C2 
            QObject::D1 
        QObject::C3 
```

还有一个函数`void QObject::dumpObjectInfo() const`可以输出某对象的信号与槽的情况:
```
QObject::connect(pA1,SIGNAL(destroyed(QObject*)), pB1, SLOT(deleteLater()) );
pA1->dumpObjectInfo();
qDebug()<<"--------------------";
pB1->dumpObjectInfo();
```
结果：
```
OBJECT QObject::A1
  SIGNALS OUT
        signal: destroyed(QObject*)
          --> QObject::B1 deleteLater()
  SIGNALS IN
        <None>
--------------------
OBJECT QObject::B1
  SIGNALS OUT
        <None>
  SIGNALS IN
          <-- QObject::A1 deleteLater()
```

## 父子对象树的特性

1. 有父对象的对象不能转移到另一个线程。对象转移到另一个线程后，其子对象线程也跟随转移

还看在多线程时分析过的`moveToThread`源码：
```
void QObject::moveToThread(QThread *targetThread)
{
    if (d->parent != 0){
        qWarning("QObject::moveToThread: Cannot move objects with a parent");
        return;
    }
    // prepare to move
    d->moveToThread_helper();
}

void QObjectPrivate::moveToThread_helper()
{
    Q_Q(QObject);
    QEvent e(QEvent::ThreadChange);
    QCoreApplication::sendEvent(q, &e);
    for (int i = 0; i < children.size(); ++i) {
        QObject *child = children.at(i);
        child->d_func()->moveToThread_helper();
    }
}
```
从代码可以看到，子对象不能脱离父对象，单独切换到与父对象不同的线程中，需要先`setParent(NULL)`脱离父对象。对子对象递归调用函数`moveToThread_helper`，所以子对象跟随对象转移到另一个线程。

2. 切换对象的线程，不能到了目标线程里再调用moveToThread,这样会失败

还是`moveToThread`部分源码:
```
if (d->threadData->thread == 0 && currentData == targetData) {
    // one exception to the rule: we allow moving objects 
    with no thread affinity to the current thread
    currentData = d->threadData;
} else if (d->threadData != currentData) {
    qWarning("QObject::moveToThread: Current thread (%p) is not the object's thread (%p).\n"
     "Cannot move to target thread (%p)\n",
     currentData->thread.load(), d->threadData->thread.load(), targetData ? targetData->thread.load() : Q_NULLPTR);
```
说白了，不能在`QThread::run()`里调用`moveToThread`
