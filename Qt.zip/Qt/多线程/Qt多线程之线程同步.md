---
title: Qt多线程之线程同步
date: 2018-05-26 21:23:58
categories:
- Qt
tags:
- 多线程
---

在程序中，通常竞争使用临界资源。这些必须互斥执行的代码段称为“临界区（Critical Section，CS）”。临界区（代码段）实施对临界资源的操作，
为了阻止问题的产生，一次只能有一个线程进入临界区。通常有关的机制或方法在程序中加上“进入”或“离开”临界区等操作。如果一个线程已经进入某个临界区，则另一
个线程就绝不允许在此刻再进入同一个临界区。临界区不是内核对象，只能对进程内部的线程进行同步。

临界区对象是定义在数据段中的一个CRITICAL_SECTION结构，Windows内部使用这个结构记录的一些信息，来确保同一个时间只有一个线程访问该临界区保护的数据。


使用临界区对象时有两点要注意：

    1. 任何访问共享资源的代码都应该放在EnterCriticalSection和LeaveCriticalSection之间，也就是这两个函数要成对出现，否则共享资源就有可能被破坏。
    2.  不要在临界区内运行较长时间，这样会影响程序的性能。




In Qt, there's no way to implement a Critical Section without context switching.

If you want to implement a Critical Section in Qt, just use QReadLocker and QWriteLocker.
Another  Qt alternative would be QMutex, but it is sadly much slower than Windows' critical section. 

    参考：[Windows线程同步之临界区对象（Critical Section）](https://blog.csdn.net/anonymalias/article/details/9133023)