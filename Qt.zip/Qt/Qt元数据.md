---
title: Qt元数据相关
date: 2019-01-05 10:03:39
categories:
- Qt
---

qDebug()<<senderSignalIndex();
QMetaMethod metaMethod = sender()->metaObject()->method(senderSignalIndex());
qDebug() << metaMethod.name();
qDebug() << metaMethod.methodSignature();
qDebug()<<"right";