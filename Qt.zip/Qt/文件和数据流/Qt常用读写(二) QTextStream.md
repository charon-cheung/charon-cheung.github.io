---
title: Qt常用读写(二) QTextStream
date: 2018-05-28 16:58:05
categories:
- Qt
tags:
---

QTextStream 专门用于读写文本形式的文件，并且自动对文本字符的本地化编码做转换，在简体中文 Windows 系统它默认按照 GBK 的中文编码读写文本文件，在 Unix/Linux 系统自动以 UTF-8 编码读写文本文件，所以几乎不需要操心文本字符编码的问题。