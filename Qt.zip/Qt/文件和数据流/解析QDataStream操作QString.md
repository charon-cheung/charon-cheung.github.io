---
title: 解析QDataStream操作QString
date: 2018-05-28 09:32:18
tags:
---

## sizeof与size,length

先看这样的代码：
```
    QString s="abcdefg";	
    qDebug().noquote()<<"sizeof:"<<sizeof(s);	   // 4
    qDebug().noquote()<<"length:"<<s.length();   // 7
    qDebug().noquote()<<"size:"<<s.size();		// 7
```
`sizeof`不是函数，`length`和`size`都是函数。
`sizeof`返回的是对象所占内存空间大小，例如在32位机器上，int对应4，double对应8。对于QString，源码中只有一个非静态成员变量`Data *d;`，其他变量全是static，不占空间，所以sizeof(s)是4。

QString源码中关于`size`和`length`的部分：
```
Data *d;
inline int QString::length() const { return d->size; }

inline int size() const { return d->size; }
```
可见二者其实是一样的，都是返回字符串长度。


Qt的几个数据类型和C++类型以及`sizeof`的对应关系:
```
typedef signed char qint8;         /* 8 bit signed */		1
typedef unsigned char quint8;      /* 8 bit unsigned */		1
typedef short qint16;              /* 16 bit signed */			2
typedef unsigned short quint16;    /* 16 bit unsigned */	2
typedef int qint32;                /* 32 bit signed */			4
typedef unsigned int quint32;      /* 32 bit unsigned */	4
```


用QDataStream操作时，我们可以有这样的代码：
```
QByteArray ba;
QDataStream ds(&ba,QIODevice::WriteOnly);
ds<<quint8(1)<<quint16(2)<<quint32(3);  //1+2+4
qDebug()<<"size:"<<ba.size();   // 7
```

## <<操作QString

但是在<<运算符在操作QString时出现了问题：
```
QByteArray ba;
QDataStream ds(&ba,QIODevice::WriteOnly);
QString  s="a";
ds<<s;
qDebug()<<"size:"<<ba.size();   // 6
```
为什么结果既不是1也不是4，而是6？解决这个问题还是用老办法，看源码。
从`qstring.cpp`中找到以下源码：
```
QDataStream  &operator<< (QDataStream &out, const QString &str)
{
    if (out.version() == 1) {
        out << str.toLatin1();
    } else {
        if (!str.isNull() || out.version() < 3) {
            if ((out.byteOrder() == QDataStream::BigEndian) == (QSysInfo::ByteOrder == QSysInfo::BigEndian)) {
                out.writeBytes(reinterpret_cast<const char *>(str.unicode()), sizeof(QChar) * str.length());
            }
            ...
```
其实QDataStream对不同类型的处理是不同的，这里QString的处理是先判断version，也就是使用QDataStream时常用的版本设置，例如`out.setVersion(QDataStream::Qt_5_8);`枚举`Version`中`Qt_1_0`的值为1，我们一般最少也得用`Qt_4_0`，也就是7。所以进入第三个if，一般用的是`BigEndia`，所以执行的是代码：
```
out.writeBytes(reinterpret_cast<const char *>(str.unicode()), sizeof(QChar) * str.length());
```
也就是执行`QDataStream &QDataStream::writeBytes`，代码在`qdatastream.cpp`，最终执行的是`QIODevice::write`。

文档对这一函数的解释：
```
    QDataStream &QDataStream::writeBytes(const char *s, uint len)

    Writes the length specifier len and the buffer s to the stream and returns a reference to the stream.

    The len is serialized as a quint32, followed by len bytes from s. Note that the data is not encoded.
```
所以除了数据之外还要把文本长度以`quint32`格式写入，也就是4个byte，而sizeof(QChar)是2，所以存入QDataStream的QString总长度应当为：
```
4+2*QString::length()
```