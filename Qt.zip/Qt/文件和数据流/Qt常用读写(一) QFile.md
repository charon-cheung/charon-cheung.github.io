---
title: Qt常用读写(一) QFile
date: 2018-05-28 13:40:50
categories:
- Qt
tags:
---

## 概述

相关类的继承关系图
![](https://lh3.googleusercontent.com/AHxBlJhZ8u72VY1YddlkNXQi-OxSoZMDW5alXklWNh3lK3ZR3JZc4naX5P_-TUlmNIaGJjIZSeqx77_3eqCvEyyaNs_ZJDF66FOdeWgCLhlDewWfZRcLeTg5aG1VL-PVhblchqk2mf17rxYCMzsGRttPBWYnhB6cGsPJcQIH5bazcD_tDcWL6UIipeAM-x4iEs82b5TPYACVubsBP8z3UFYrGSaUFmozYOi-bNexhX0rALa88y-QUz6jvalYL_dmgrQgl77JcKKIuB1DX8kLOqg2ygfaqt95UdAQWZQ5UiAEhWMU7EVZHy2mRXBArEEUyhC8tW4HVCcNSSCom3LIQGm1Ut8AFYUUatAHOcY5s96Iu1v2rQH70DEMbols7qSKbTf1QZqjQpRxyn_HVw8J0UtqEhyOLv1wWicojGZgx-mL6aeNhWuJGWM0HEZaEp231UiOEH1FRlP7IwfNucMS1DyTYzrITQ7IYA3B0N-zBcMtl7EQcTczsBEZAlCuD27U8yuHGzkztD-oG9geOd8TW2jFakjS6sGxj0HvmqOTnArorNoldE7iACYXXrPjPRK92fzT8KtinmboOVUNTmp1gw5o2eT4k_fM=w1346-h725-no)
虽然QFile自己有读写文件中字节、字节数组的函数，但是直接用 QFile 类的接口函数读写文件的情况是相对少见的，因为 QFile 的读写函数功能比较简单，就是面向字节数据进行读写。

QFile的基类**QFileDevice**是对文件设备的抽象，其实在 Unix 和 Linux 系统中所有东西都是文件设备，就连硬件设备也抽象成文件设备，一切皆文件嘛，QFileDevice 就是描述文件设备的类，QFileDevice 这一层基类的接口函数比较少，可以不用管。

**QSaveFile**是保存文件类，就为了安全地保存文件而设计的，因为程序运行时可能有 bug 导致崩溃，如果崩溃时正在写入文件，那么文件被改写了一部分，但又没修改完全，会导致原始文件的损坏。QSaveFile 解决了文件的不安全读写，避免出现半吊子问题，QSaveFile 有两个重要函数：cancelWriting() 函数取消写入操作，commit() 提交所有写入操作

## 基本函数

QFile的构造函数：
```
    QFile();
    QFile(const QString &name);  // fileName()返回文件名		
    QFile(QObject *parent);		// 配合setFileName()
    QFile(const QString &name, QObject *parent);
```
打开函数有3个，但基本只用1个：
```
bool open(OpenMode flags) Q_DECL_OVERRIDE;
```
其中`OpenMode`枚举类型是在基类  QIODevice 定义的，有如下打开模式：
![](https://lh3.googleusercontent.com/thvlCAwthFaQYoPbr-NDfX2XdFzfrwliQjB2SKIYjbbRyujnQ4XIXWs9-R9ZBahTGFwN9NC9fdlJkoA72UoOwb-OESBqEhu-kSH2cTTgGiCvjcG4yMqlTPXrCHxL_oeybsSCDxSKg6Br5leOegHTwcYPrvlSehNjCTO8cXPSc-9u7xSvlDRyQ0hCxHx2p3u5WN43AofsMgL-XHmjGNrwuG0W7VxWtVaRmmaW_fgbtdzzmdBJ5XXcXz7kk7totBvfU3HqbAf3HwYzJve01kAIQrhpw9P-AQuMmVLFDQWnmhDhpNQXaRtdTxGOwu7mSimvo60X9XgimlVvea1942GyxkcCqmb8mbZ8EU1aFWp3rCzQ3pTctnt2nJ7Z4M6WG6KJ8UxufoOD-lMCdOho0Pop9bE-U_3HtMNr85Ol-8nOkqvT9JWOCUeofFv-Ovn1boiLeun-Jy0MtAsHns-o8X-zo2wzKBWBAzaF0tZFPR_LxiYzBJZ7KuNiwQmV_R-hpkhMGeYsbO1gQr4RAMFGlYTc_B6ngtRrDU-3eihQEC5qGAFl4lXn-ZeCZvdCUtI7LaX-u2_G2ZoRSn4nfdk_MUpRl6lAi_MB-N5k=w1749-h498-no)
文件读取时，常见组合：
```
file.open(QIODevice::ReadOnly);    //以只读方式打 开文件
file.open(QIODevice::ReadOnly | QIODevice::Text);    //确定是读取文本文件，并且自动把换行符修改为 '\n'
```
 <font color = red size =3> 注意以`QIODevice::Text`模式打开文件时，读写的数据不一定是原始数据 </font>，因为 QFile 自动把换行符做了转换，读取得到的缓冲区数据与原始文件是可能不一样的，比如 Windows 文本，换行符是 "\r\n" 两个字符，用 QIODevice::Text 读取时只会看到 '\n' 一个字符；写入时就反过来，代码写入一个 '\n'，实际文件就是两个连续字符 "\r\n"，所以要注意 QIODevice::Text 模式读写的不一定是原始数据。

对于文件写入时，其常用打开模式如下：
```
file.open(QIODevice::WriteOnly);    //以只写模式打开，会清空旧数据
file.open(QIODevice::WriteOnly | QIODevice::Truncate);    //只写模式，清空旧数据
file.open(QIODevice::WriteOnly | QIODevice::Append);     //只写和追加模式，不会清空旧数据
```
如果文件打开时既要读，又要写：
```
file.open(QIODevice::ReadWrite);    //读写模式，旧数据不会清空，可以读出来
```

## 读写字符

首先是简单的字节读写函数：
```
bool QIODevice::​getChar(char * c)
```
参数指针 c 就是读取的一个字节将要存到的变量指针，程序员需要自己先定义一个 char 变量，把这个变量地址传递给 ​getChar() 函数，如果读取一字节成功就返回 true；如果之前已经到了文件末尾，没有字节可以读了，就返回 false。

写入一个字节到文件中，应该使用函数：
```
bool QIODevice::​putChar(char c)
```
这个函数会把字节 c 写入文件，并将文件游标加一。

这里我们专门讲一下文件游标，文件在读写时，共同使用一个唯一的游标（QFile内部有），我们这里随便取个名字叫 pos（Position），这个 pos 在文件刚打开时一般处于文件开头位置0：
![](https://lh3.googleusercontent.com/zRVU0Zv0l3xDr9sUs3AAehvwisldduhJ2V4WEmAn-UI6k4wJLXpEzE4A3yNnQI_MpwwSOgXWdT0Zv4zrQT0aJDyU17MFpdhqVKRQzRgflFtA1sPVnT3Quh4qWiDO35eiZSfxzIkgFobtteT1NNq6MyCma82rv5D1AOqPSOuxacjo9UxHe5CMP9FCTI28LcNUQrLusYpHsuy3jYUfVxnB17ShkgD3twOJL3YUrE7GUEMb3pweTUKfpCZlhAPK_-oT3l1NKj4OvjM6Oy7LcjTx_ith1zWO7H7dGMtajJ8uw_yBIywdkFse14Rn1P_Awk87lnBJc_MDK4m_QHYeswrqKWl1xPwo6l93Yf68owI_LiqIQd2Pww66UrWq8HxFzwDS3quDe-v6XJqcdjSMTDOhz_eSkc4WxocAW2qqDaAXH2BU3WLRRv4VwH05Ii3GzqXLxxB-GBr5Le8zracsaUDmelaiiF-pTc0GhogbulpyqMo2kUsL4kEhTy6vCZpAoXlcaTbQFcYt_PzW_cTybn2yl5vTo5pAkXiY3-xasSVWyhiAihRcIAnZyBal_T6-uetSskn3bus8bhoqB17D2PIQLP_hOIBKPa6H=w1092-h302-no)
对于函数 `​getChar()`和`putChar()`，每调用一次，文件游标就加 1，如果连续调用了 N 次，游标 pos 就会移动到位置N。`ungetChar()`函数如果操作正确，那么会使 pos 自动减一，这个游标都是 QFile 自动控制，一般不需要手动移动游标。读到文件末尾位置就无法再读数据了。

QFile 基类有快捷函数判断文件游标是否已到达文件末尾：
```
bool QFileDevice::​atEnd() const
```
## Qt读函数

对于字节读取函数，文件游标是按一字节移动的，如果要读取大段数据块，那么可以使用：
```
qint64 QIODevice::​read(char * data, qint64 maxSize)
```
data 通常是程序员手动分配的缓冲区，比如 `char *buff =  new char[256];`
`maxSize`就是最多读取的字节数目，一般是手动分配的缓冲区大小，比如 256。
该函数返回值一般就是正确读取的字节数目，因为当前游标之后可能没有 256 字节，那么有几个字节读几个字节。如果 read() 函数在读取之前就到了文件末尾或者读取错误，那么返回值是 -1 。注意`OpenFlag`不要是只读的。

更常用的函数是：
```
QByteArray QIODevice::​read(qint64 maxSize)
```
这里的 read() 函数会把读取的字节数组存到 QByteArray 对象并返回，参数里的 maxSize 就是最多读取的字节数目。返回的 QByteArray 对象里面，可以用 QByteArray 自己的 `QByteArray::​size()` 函数判断读了多少字节，如果文件后面没字节可读或读取错误，那么 QByteArray 的size就是 0 。

其他常用函数：
```
QByteArray QIODevice::​readAll()

qint64 QIODevice::​readLine(char * data, qint64 maxSize)

QByteArray QIODevice::​readLine(qint64 maxSize = 0)
```
第一个`readLine()`是程序员手动分配缓冲区，第二个不需要手动分配缓冲区。
`readLine()`是从文件或设备里面读取一行 ASCII 字符，最多读取 maxSize-1 字节，因为最后一个字节预留给字符串结尾NULL字符。该函数返回值是真实读取的字节数目，如果读取出错或无数据可读就返回-1，它总会在实际读取的字符串末尾会自动添加一个字符串终结符 0 。

​readLine() 会一直读取数据直到如下三个条件之一满足：
① 第一个 '\n' 字符读取到缓冲区。
② maxSize - 1 字节数已读取，最后一个字节预留给 0 。
③ 文件或设备读取已经到末尾。

## Qt写函数

```
qint64 QIODevice::​write(const char * data, qint64 maxSize)
```
data 就是缓冲区数据指针，maxSize 是最多写入的字节数。 返回值是真实写入的字节数，因为可能出现磁盘不够的情况。 如果返回值是 -1，那么可能是写入出错或者无写入权限。这个写函数不区分 data 缓冲区里面的 '\0' 字符和普通字符串字符。

```
qint64 QIODevice::​write(const char * data)
```
函数没指定缓冲区大小，会将参数里的data当作'\0'结尾的普通字符串，写入该字符串。这个函数等价于下面这句代码：
```
QIODevice::write(data, qstrlen(data));
```

第三个写函数也很常用：
```
qint64 QIODevice::​write(const QByteArray & byteArray)
```
byteArray 里面有多少字节就写入多少，这个也是不区分 '\0' 字符和普通字符串字符。写操作函数也都会移动文件游标 pos，具体是看实际写入了多少字节。

## 其他常用函数

手动移游标pos，那么通过下面函数：
```
bool QFileDevice::​seek(qint64 pos)
```
​如果成功移动游标，那么会返回 true，否则返回 false。最好不要用 seek 函数移动游标到超出文件尺寸的位置，这样会导致无法预料 的结果。

如果希望设置文件尺寸，提前在磁盘上分配空间，可以用如下函数：
```
bool QFile::​resize(qint64 sz)
```
参数 sz 就是新的文件大小，如果新大小比旧的大，那么新增空间内容是随机的，需要程序员以后手动填充数据。重置大小成功就返回 true，否则返回 false。

文件打开和读写操作结束之后，就可以关闭文件：
```
void QFileDevice::​close()
```
结束后，如果不关闭文件，文件大小是0，但是能正常打开；如果删除文件，会报警：文件被占用。

在写操作过程中，如果需要立即把 Qt 内部写缓冲区的数据写入磁盘，可以调用：
```
bool QFileDevice::​flush()    //这个函数很少用到，文件 关闭时自动会执行 flush
```

```
bool QFile::​exists() 或 QFileInfo::exists	// 判断文件或同名文件夹是否存在 (最好不用)
bool QFileInfo::isFile()	// 判断文件是否存在
bool QFileInfo::isDir() 或 QDir::exists		// 判断文件夹是否存在

bool QFile::​remove()	// 删除当前文件，删除之前文件会自动被关闭，然后删除

bool QFile::​rename(const QString & newName)//重命名为新名字newName，重命名之前，该文件会自动关闭

Permissions QFile::​permissions() const	//获取文件权限的函数, 详见枚举值

bool QFile::​setPermissions(Permissions permissions)	  // 设置文件权限的函数
```
