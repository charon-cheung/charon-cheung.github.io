---
title: Qt常用读写(三) QDataStream
date: 2018-05-28 16:57:36
categories:
- Qt
tags:
---

QDataStream 是 Qt 独有的“串行化数据流”，可以用于文件读写和网络数据流读写。串行化数据流，就是对所有已知数据类型全部做格式封装，相当于全 自动打包成结构体（不需要人为定义）收发，只要在发送（写入）和接收（读取）时按照相同顺序填充即可，其他的都交给 Qt 库处理，程序员就不用管数据是如何打包解包的，如果数据类型变了，只需要修改写入和读取的两句代码，其他的都不需要调整。
```cpp
    QString s="abcdefg";
    QByteArray ba;
    QDataStream   Out(&ba,QIODevice::WriteOnly);    //默认是ReadOnly
    out<<int(1)<<int(2)<<int(3)<<s;  //1+2+4+6

    QDataStream   In(&ba,QIODevice::ReadOnly);
    int a,b,c;
    QString ss;
    In>>a>>b>>c>>ss;
    qDebug()<<a<<"  "<<b<<"  "<<c<<"  "<<ss;
```

游标操作：
    ds.device()->seek(0);
    ds<<10<<20<<30<<QString("dasfgserth");