---
title: Qt内存管理(四) deleteLater
categories:
  - Qt
tags:
  - 内存管理
abbrlink: 892b2dbc
date: 2018-06-20 22:23:34
---

源码：
```
void QObject::deleteLater()
{
    QCoreApplication::postEvent(this, new QDeferredDeleteEvent());
}

bool QObject::event(QEvent *e)
{
    switch (e->type()) {
    ......
    case QEvent::DeferredDelete:
        qDeleteInEventHandler(this);
        break;
	}
}

void qDeleteInEventHandler(QObject *o)
{
    delete o;
}
```
从源码可以看到，返回到事件循环后，调用`deleteLater()`的对象才会被销毁，否则不执行。

如果线程中没有运行着的事件循环，线程中的对象调用了`deleteLater()`，当线程结束后对象才被销毁。当第一次`QDeferredDeleteEvent`传递给事件循环后，对象的任何待处理事件(pending events)都从事件队列中移除。

Qt中不建议手动`delete`掉QObject对象。原因一：不注意父子关系会导致某个对象析构两次，一次是手动析构，还有一次是parent析构，后者可能会出现delete堆上的对象。

原因二：删除一个pending events等待传递的QObject会导致崩溃，所以不能直接跨线程删除对象，而QObject析构函数会断开所有信号和槽，因此用`deleteLater`代替比较好，它会让所有事件都发送完一切处理好后马上清除这片内存，而且就算调用多次的deletelater也是安全的。

结合第一篇和本篇，可以明白为什么Qt的代码里很少有直接用`delete`的场合了。

参考：
[How delete and deleteLater works with regards to signals and slots in Qt?](https://stackoverflow.com/questions/4888189/how-delete-and-deletelater-works-with-regards-to-signals-and-slots-in-qt)
[When to use deleteLater](https://stackoverflow.com/questions/22376298/when-to-use-deletelater)