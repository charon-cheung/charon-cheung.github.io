---
title: Qt内存管理(二) qDeleteAll与clear
categories:
  - Qt
tags:
  - 内存管理
abbrlink: fdf72acc
date: 2018-05-14 19:29:20
---

qDeleteAll：专门用于指针容器，对容器或者迭代器中的每个对象进行`delete`操作，而不是从容器中移除对象。源代码如下：
```cpp
void qDeleteAll(ForwardIterator begin, ForwardIterator end)
 {
      while (begin != end)
      {
          delete *begin;
          ++begin;
      }
 }
 ```

测试代码如下：
```cpp
    typedef struct _Defs
    {
        int a;
        double d;
        QString s;
    } Def;

    QList<Def*> defs;
    for(int i=0;i<500000;i++)
    {
        Def* dd = new Def;
        dd->a = 12;
        dd->d = 4.23;
        dd->s = "jda";
        defs.append(dd);
    }
    qDebug()<<"before qDeleteAll: "<<defs.size();
    qDeleteAll(defs);
    qDebug()<<"after qDeleteAll: "<<defs.size();
    defs.clear();
```
运行结果发现，不调用`qDeleteAll`的情况下，程序占内存78M；加上之后，只占内存12M。但是前后的size没有变化。

当T的类型为指针时，调用clear方法能置空，但并不能释放其内存。qDeleteAll可以释放容器元素内存，但没有对容器的置空操作，也就是size没变。所以**qDeleteAll之后必须加上clear方法**。