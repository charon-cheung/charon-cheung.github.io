---
title: Qt内存管理(五) 自动垃圾回收机制
categories:
  - Qt
tags:
  - 内存管理
abbrlink: f6f6fd5e
date: 2018-06-25 21:53:50
---

实现自动垃圾回收的工具主要是`Qt对象清理器`，也就是`QObjectCleanupHandler`类，它监视多个QObject对象的生命期。当你想知道被别人拥有的QObject对象是否被删除时，这个类就派上了用场。例如引用(referencing memory)了程序中的共享库内存的场合。

为了追踪某些QObject对象,使用`add()`添加对象，不再跟踪时使用`remove()`。被`cleanup handler`追踪的对象在别处被删除后，它会自动将其`remove`。要删除所有添加的对象用`clear()`或者销毁`cleanup handler`，`isEmpty()`判断是否其中还有对象。

这个类的源码很简单：
```cpp
class Q_CORE_EXPORT QObjectCleanupHandler : public QObject
{
    Q_OBJECT
public:
    QObjectCleanupHandler();
    ~QObjectCleanupHandler();

    QObject* add(QObject* object);
    void remove(QObject *object);
    bool isEmpty() const;
    void clear();
private:
    // ### move into d pointer
    QObjectList cleanupObjects;
private Q_SLOTS:
    void objectDestroyed(QObject *);
};
```

add函数很简单:
```cpp
QObject *QObjectCleanupHandler::add(QObject* object)
{
    if (!object)
        return 0;
    connect(object, SIGNAL(destroyed(QObject*)), this, SLOT(objectDestroyed(QObject*)));
    cleanupObjects.insert(0, object);
    return object;
}
```
实际就是连接了`destroyed`信号，再将QObject对象插入链表中，`objectDestroyed`槽函数实际就是`remove`函数:
```cpp
int index;
if ((index = cleanupObjects.indexOf(object)) != -1)
{
    cleanupObjects.removeAt(index);
    disconnect(object, SIGNAL(destroyed(QObject*)), this, SLOT(objectDestroyed QObject*)));
}
```
析构函数实际调用`clear()`:
```cpp
void QObjectCleanupHandler::clear()
{
    while (!cleanupObjects.isEmpty())
        delete cleanupObjects.takeFirst();
}
```

使用比较简单，参考[这篇文章](https://blog.csdn.net/taiyang1987912/article/details/29271549)吧。
