---
title: QProcess常用方法
date: 2018-12-13 20:56:18
categories:
- Qt
---

### 执行某命令，并输出执行的结果

一般在Linux环境下使用:
```cpp
QProcess* p = new QProcess;
p->start("ls");
p->waitForFinished(-1);		//阻塞直至执行完毕，参数是毫秒，指定阻塞时间，但-1时会一直阻塞
QByteArray ba = p->readAll();	//执行结果
qDebug()<<QString(ba);
```

### 启动外部程序

在Qt中，做这个工作的非QProcess莫属了，要启动当前程序的另一个进程，又要使二者没有"父子"关系。
`QProcess::startDetached(qApp->applicationFilePath(), QStringList());`如果路径中不包含空格，只用第一个参数也可以。

所以重启就是二者的结合：
```cpp
qApp->quit();
QProcess::startDetached(qApp->applicationFilePath(),QStringList());
```