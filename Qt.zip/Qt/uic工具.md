---
title: 解析Qt的ui_*.h文件
date: 2018-04-27 21:16:24
categories:
- Qt
---

`mainwindow.h`常见的几行：
```
namespace Ui {  
    class MainWindow;  
}  
	......
private:  
    Ui::MainWindow *ui; 
```
`mainwindow.cpp`常见的几行：
```
#include "ui_mainwindow.h" 
MainWindow::MainWindow(QWidget *parent) :  
    QMainWindow(parent),  
    ui(new Ui::MainWindow)  
{  
    ui->setupUi(this);  
}  
```
ui文件实际是xml格式的，Qt编译时，先用uic工具将`mainwindow.ui`编译生成`ui_mainwindow.h`，转化为c++类，就是 **Ui::MainWindow**。头文件的部分代码：
```
QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QRadioButton *radioButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    
void setupUi(QMainWindow *MainWindow)
{
if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(402, 302);
        centralWidget = new QWidget(MainWindow);
        ......
void retranslateUi(QMainWindow *MainWindow)
{
   MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
   radioButton->setText(QApplication::translate("MainWindow", "RadioButton", nullptr));
    }
}

namespace Ui {
	class MainWindow: public Ui_MainWindow {};
}

QT_END_NAMESPACE
```
文件开头的注视是说明不要修改这个文件，因为修改了也没用，下次 uic 工具会自动生成这个文件，之前的修改就被覆盖了。

可以看到在ui文件中拖的控件就是Ui_MainWindow类中的public成员变量。
**布局函数**：setupUi成员函数，其参数是个QMainWindow指针。实际上，不拖控件而直接在`mainwindow.cpp`中建立控件的方法就相当于自己写setupUi函数的部分代码。

retranslateUi:重新翻译界面，如果做了多国语言翻译，这个函数可以将界面翻译成其他语言显示。
开头的 QT_BEGIN_NAMESPACE 和结尾的 QT_END_NAMESPACE 两个宏，其实是空宏

`QMetaObject::connectSlotsByName(MainWindow);` 是根据信号和槽函数名称等实现自动关联的关键函数


Ui命名空间中的<font color = blue>  <font size= 3> MainWindow </font> </font>与继承自QMainWindow的<font color = red>  <font size= 3>MainWindow</font> </font>不是一回事，前者仅继承Ui_MainWindow，后者的private成员ui指针指向前者。

假如在ui模式里把顶级窗口MainWindow改名为`myWindow`，运行程序会报错。因为`ui_mainwindow.h`也变化了：
```
class Ui_myWindow
{
  ......
  void setupUi(QMainWindow *myWindow)
  ......
  retranslateUi(myWindow);
  QMetaObject::connectSlotsByName(myWindow);
  ......
  namespace Ui {
    class myWindow: public Ui_myWindow {};
} 
```
需要对mainwindow.h和cpp做相应修改：
```
namespace Ui {
    class myWindow;
}
```
再把Ui::MainWindow都改为Ui::myWindow，这样就编译通过了。其实这种写法比较好，不会混淆两个MainWindow。
