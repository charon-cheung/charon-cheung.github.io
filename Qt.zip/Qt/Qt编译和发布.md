---
title: Qt的编译和发布
date: 2018-07-24 09:18:56
categories:
- Qt
tags:
---

用Mingw编译生成的exe文件，在自己电脑上可以独立运行，但MSVC编译的却不行。报错:
![](https://c1.staticflickr.com/1/934/29731569638_8c5363da41_b.jpg)

使用Qt MSVC的编译环境运行`windeployqt`命令，生成库文件后，再运行exe则正常。